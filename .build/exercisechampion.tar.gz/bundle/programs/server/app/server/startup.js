(function(){//Meteor.startup(function () {
//	Log.find().observe({
//		changed: function (s, p) {
//		}
//	});
//});

})();
