(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;

/* Package-scope variables */
var Tracker, Deps;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.deps = {
  Tracker: Tracker,
  Deps: Deps
};

})();

//# sourceMappingURL=deps.js.map
