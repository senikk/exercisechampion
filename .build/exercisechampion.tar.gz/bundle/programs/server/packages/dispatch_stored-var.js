(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dispatch:stored-var'] = {};

})();

//# sourceMappingURL=dispatch_stored-var.js.map
